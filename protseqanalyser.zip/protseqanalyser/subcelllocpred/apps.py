from django.apps import AppConfig


class SubcelllocpredConfig(AppConfig):
    name = 'subcelllocpred'
