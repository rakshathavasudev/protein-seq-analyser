from django.apps import AppConfig


class MultiprotseqalignConfig(AppConfig):
    name = 'multiprotseqalign'
