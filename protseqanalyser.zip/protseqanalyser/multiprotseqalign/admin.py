from django.contrib import admin
from .models import ProteinSequence

# Register your models here.
admin.site.register(ProteinSequence)
