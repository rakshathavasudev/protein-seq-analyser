from django.apps import AppConfig


class SecstructclasspredConfig(AppConfig):
    name = 'secstructclasspred'
