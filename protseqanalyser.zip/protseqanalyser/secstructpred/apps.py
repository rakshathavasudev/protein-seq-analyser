from django.apps import AppConfig


class SecstructpredConfig(AppConfig):
    name = 'secstructpred'
