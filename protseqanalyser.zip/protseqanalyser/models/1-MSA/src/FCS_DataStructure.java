import java.util.ArrayList;


public class FCS_DataStructure {
		
	String FCS = "";
	ArrayList<FCS_RowStructure> frs = new ArrayList<FCS_RowStructure>();
	double maxValue = 0;
	int numOfSeq = 0;

}
