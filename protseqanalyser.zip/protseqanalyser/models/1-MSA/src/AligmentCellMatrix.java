
public class AligmentCellMatrix {
	double value =0.0;
	String trackback = "NULL";
	char seqChar = ' ';
	char gap = '=';

}
