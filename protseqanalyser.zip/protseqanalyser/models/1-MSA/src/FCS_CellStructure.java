import java.util.TreeSet;


public class FCS_CellStructure {
	
	int Count = 0;
	TreeSet<Integer> ListOfSequencesAtCell = new TreeSet<Integer>();

}	
