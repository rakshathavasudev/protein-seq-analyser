from django.apps import AppConfig


class FoldrecogConfig(AppConfig):
    name = 'foldrecog'
